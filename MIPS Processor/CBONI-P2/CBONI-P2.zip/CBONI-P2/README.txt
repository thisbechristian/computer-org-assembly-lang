Christian Boni
cjb90@pitt.edu

Tested using:
function, addshift, increment, load, and loadstore
and each test seemed to be functioning correctly and produced the correct results.
